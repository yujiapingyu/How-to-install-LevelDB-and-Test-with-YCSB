Interface to leveldb for integration into ycsb using leveldb JNI.

To open shell for interactive debugging:
./bin/ycsb shell leveldb

leveldb: https://code.google.com/p/leveldb/
