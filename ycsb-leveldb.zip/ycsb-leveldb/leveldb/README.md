Interface to leveldb for integration into ycsb. Based on simpleleveldb, a http daemon for leveldb. Make sure to start the daemon before running any workloads.

To open shell for interactive debugging:
./bin/ycsb shell leveldb

leveldb: https://code.google.com/p/leveldb/
simpleleveldb: https://github.com/bitly/simplehttp/tree/master/simpleleveldb
