buffered_socket
===============

a simple abstraction on bufferevent for arbitrary TCP sockets

see `demo.c` for an example

dependencies
============

 * [libevent](http://www.monkey.org/~provos/libevent/) 
