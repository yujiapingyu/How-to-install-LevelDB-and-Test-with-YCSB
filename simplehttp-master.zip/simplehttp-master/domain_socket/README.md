domain_socket
=============

an async C library for creating, listening, and communicating over unix domain sockets.

see `demo.c` for an example

dependencies
============

 * [libevent](http://www.monkey.org/~provos/libevent/) 
